#include <iostream>
#include <stdlib.h>
#include <iomanip>

using namespace std;

int main()
{
    short int counter = 1, hours, speed;
    int distance;

    system("cls");
    cout << "This program will calculate and display the distance traveled \n";
    cout << "each hour for the number of hours traveled.\n\n";

    cout << "What is the speed of the vehicle in mph? ";
    cin >> speed;
    while(speed < 0)
        {
            cout << "The speed cannot be negative.\n\n";
            cout << "What is the speed of the vehicle in mph? ";
            cin >> speed;
        }
    cout << endl;

    cout << "How many hours has it traveled? ";
    cin >> hours;
    while(hours < 1)
    {
        cout << "The number of hours cannot be less than one.\n\n";
        cout << "How many hours has it traveled? ";
        cin >> hours;
    }
    cout << endl;

    cout << setw(11) << left << "   Hour";
    cout << setw(17) << right << "Distance Traveled\n";
    while(counter <= hours)
    {
        distance = speed * counter;
        cout << setw(4) << left << "  " << counter;
        cout << setw(15) << right << distance << endl;
        ++counter;
    }

    return 0;
}
