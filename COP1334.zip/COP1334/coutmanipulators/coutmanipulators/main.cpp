/*  This program demonstrates the use of cout manipulators to format numeric output

    The output manipulators are:

        setw(x)         -   Establishes a print field of x number of spaces. print in a field at least x spaces wide.
                            Use more spaces if field is not wide enough.
        fixed           -   Displays floating-point numbers in fixed point notation.
        showpoint       -   Always print decimqal for floating-point numbers. Causes a decimal point and trailing zeros
                            to be displayed, even if there is no fractional part.
        setprecision(x) -   When used with fixed, print floating-point value using x digits after the decimal.
                            Without fixed, print floating-point value using x significant digits.
        left            -   Causes subsequent output to be left justified.
        right           -   Causes subsequent output to be right justified.
*/

#include <iostream>
#include <iomanip>

using namespace std;

int main()
{
    // Default alignment of numeric output. (up to six significant digits)
    cout << "Original DEFAULT alignment for numbers.\n\n";
        cout << 123.50 << endl;
        cout << 123.5073 << endl;
        cout << 12.50 << endl;
        cout << 1.5073 << endl;
        cout << 1.0 << endl<< endl;
        cout << endl;

    // Default numeric output alignment using output manipulator setw(). (displayed right justified)
    cout << "Numbers aligned using setw().\n\n";
        cout << "(" << setw(9) << 123.50 << ")" << endl;
        cout << "(" << setw(9) << 123.5073 << ")"<< endl;
        cout << "(" << setw(9) << 12.50 << ")" << endl;
        cout << "(" << setw(9) << 1.5073 << ")" << endl;
        cout << "(" << setw(9) << 1.0 << ")" << endl;
        cout << endl;

    // Numbers displayed using output manipulator setprecision and setw()
    cout << "Numbers displayed using setprecision() and setw().\n\n";
        cout << setprecision(5);
        cout << "(" << setw(9) << 123.50 << ")" << endl;
        cout << "(" << setw(9) << 123.5073 << ")" << endl;
        cout << "(" << setw(9) << 12.50 << ")" << endl;
        cout << "(" << setw(9) << 1.5073 << ")" << endl;
        cout << "(" << setw(9) << 1.0 << ")" << endl;
        cout << endl;

    // Numbers displayed using output manipulator showpoint
    cout << "Numbers displayed using showpoint, setprecision(), and setw().\n\n";
        cout << showpoint;
        cout << "(" << setw(9) << 123.50 << ")" << endl;
        cout << "(" << setw(9) << 123.5073 << ")" << endl;
        cout << "(" << setw(9) << 12.50 << ")" << endl;
        cout << "(" << setw(9) << 1.5073 << ")" << endl;
        cout << "(" << setw(9) << 1.0 << ")" << endl;
        cout << endl;

    // Numbers displayed using output manipulator fixed
    cout << "Numbers displayed using fixed, showpoint, setprecision(), and setw().\n\n";
        cout << fixed;
        cout << "(" << setw(9) << 123.50 << ")" << endl;
        cout << "(" << setw(9) << 123.5073 << ")" << endl;
        cout << "(" << setw(9) << 12.50 << ")" << endl;
        cout << "(" << setw(9) << 1.5073 << ")" << endl;
        cout << "(" << setw(9) << 1.0 << ")" << endl;
        cout << endl;

    cout << setprecision(2);
    cout << "(" << left << setw(13) << "Cat" << ")" << "(" << right << setw(10) << 35000.00 << ")     (" << left << setw(13)
         << "Tom" << ")" << "(" << right << setw(8) << .363 << ")" << endl;
    cout << "(" << left << setw(13) << "Skateboard" << ")" << "(" << right << setw(10) << 99.50 << ")     (" << left << setw(13)
         << "Washington" << ")" << right << "(" << setw(8) << 44.28 << ")" << endl;
    cout << "(" << left << setw(13) << "Boat" << ")" << "(" << right << setw(10) << 150000.75 << ")     (" << left << setw(13)
         << "Maria" << ")" << "(" << right << setw(8) << 444.287 << ")" << endl;
    cout << "(" << left << setw(13) << "Bike" << ")" << "(" << right << setw(10) << 500.00 << ")     (" << left << setw(13)
         << "Bo" << ")" << "(" << right << setw(8) << 4.28 << ")" << endl;

    return 0;
}
