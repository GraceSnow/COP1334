/* Grace Benson
   Assignment #6

   This program will read data from a file and calculate the balance of a savings
   account at the end of a period of time. Then it will display the balance, the total amount
   of deposits, the total amount of withdrawals, and the total interest earned in a
   savings account.
   --------------------------------------------------
   INPUT                        OUTPUT
   -----                        ------
   Interest rate                Interest rate
   Starting balance             Starting balance
   Months                       Months
   Deposits                     Deposits
   Withdrawals                  Withdrawals
                                Total deposited
                                Total interest earned
   --------------------------------------------------
*/

   //*** Program preprocessors - constants, libraries, and header files
#include <iostream>					//*** cin and cout
#include <iomanip>					//*** cout manipulator options
#include <string>					//*** string datatype
#include <cstdlib> // clear screen
#include <iostream>
#include <fstream> // Used to input to a file

using namespace std;

int main()
{
    double Balance, AnnualInterestRate, AmountDeposited, AmountWithdrawn;
    int Months;
    double TotalWithdrawn = 0, TotalDeposited = 0, TotalInterestEarned = 0, MonthlyInterest = 0;
    ifstream InputRecord;  // Variable name associated with input stream

    system("cls");  // clear screen
    // Program description
    cout << "This program will read data from a file and calculate the balance of a savings account at the end of a \n";
    cout << "period of time. Then it will display the balance, the total amount of deposits, the \n";
    cout << "total amount of withdrawals, and the total interest earned in a savings account.\n\n";

    // input stream associated with the output file
    //InputRecord.open("Test.txt");
    InputRecord.open("C:..\\Test.txt");

    if(!InputRecord)
    {
        //** show error message and end program if file is not found
        cout << "File not found!\n";
        return 0;   // Exit program
    }

    InputRecord >> AnnualInterestRate >> Balance >> Months; // Read in data from file

    for(int x = 1; x <= Months; x++)
    {
        // Repeat for number of months
        InputRecord >> AmountDeposited >> AmountWithdrawn;

        Balance += AmountDeposited - AmountWithdrawn;
        MonthlyInterest = (AnnualInterestRate / 12) * Balance;
        Balance += MonthlyInterest;

        if(Balance < 0)
            {
                cout << "\n\nThe account balance is negative.\n\n";
                break;
            }

        TotalWithdrawn += AmountWithdrawn;
        TotalDeposited += AmountDeposited;
        TotalInterestEarned += MonthlyInterest;
    }

    cout << "\n\nAccount Balance: " << setw(4) << setprecision(2) << fixed << right << Balance;
    cout << "\nTotal Deposits: " << setw(4) << setprecision(2) << fixed << right << TotalDeposited;
    cout << "\nTotal Withdrawn: " << setw(4) << setprecision(2) << fixed << right << TotalWithdrawn;
    cout << "\nTotal Interest Earned: " << setw(4) << setprecision(2) << fixed << right << TotalInterestEarned;

    // Close input file
    InputRecord.close();

    return 0;
}

