#include <iostream>
#include <fstream> // Used to input to a file

using namespace std;

int main()
{
    string Name, Phone, Email, ZipCode, DOB;
    int Visitor = 0;
    ifstream InputRecord;  // Variable name associated with input stream

    // Input stream associated with the input file
    InputRecord.open("C:\\Users\\Grace.Benson001\\Desktop\\Test2.txt");

    if(!InputRecord)
    {
        cout << "File not found!\n";
        return 0;   // Exit program
    }

    /*InputRecord >> Name >> Phone >> Email >> ZipCode>> DOB;
    while(InputRecord)
    {
        cout << ++Visitor << " - " << Name << " - " << Phone << " - " << Email << " - " << ZipCode << " - " << DOB << "\n";
        InputRecord >> Name >> Phone >> Email >> ZipCode >> DOB;
    }*/

    getline(InputRecord, Name);
    getline(InputRecord, Phone);
    getline(InputRecord, Email);
    getline(InputRecord, ZipCode);
    getline(InputRecord, DOB);
    while(!InputRecord.eof())
    {
        cout << ++Visitor << " - " << Name << Phone << Email << ZipCode << DOB << endl;
        getline(InputRecord, Name, ',');
        getline(InputRecord, Phone, ',');
        getline(InputRecord, Email, ',');
        getline(InputRecord, ZipCode, ',');
        getline(InputRecord, DOB);
    }
    // Close input file
    InputRecord.close();

    return 0;
}
