#include <iostream>
#include <fstream> // Used to output to a file

using namespace std;

int main()
{
    string Name, Phone, Email, ZipCode, DOB;
    ofstream OutputRecord;  // Variable name associated with output stream

    // Output stream associated with the output file
    OutputRecord.open("C:\\Users\\Grace.Benson001\\Desktop\\Test2.txt");

    cout << "Enter first name or -99 to terminate: ";
    cin >> Name;
    while(Name != "-99")
    {
        cout << "Enter phone (999-9999), email, zip code, and DOB (MM/DD/YYY) separated by spaces.\n";
        cin >> Phone >> Email >> ZipCode >> DOB;

        OutputRecord << Name << "," << Phone << "," << Email << "," << ZipCode << "," << DOB << endl;

        cout << endl;
        cout << "Enter first name or -99 to terminate program: ";
        cin >> Name;
    }




    // Close output file
    OutputRecord.close();

    return 0;
}
