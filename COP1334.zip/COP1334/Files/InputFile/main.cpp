#include <iostream>
#include <fstream> // Used to input to a file

using namespace std;

int main()
{
    string Name, Phone, Email, ZipCode, DOB;
    int Visitor = 0;
    fstream InputRecord;  // Variable name associated with input stream

    // Input stream associated with the input file
    InputRecord.open("C:\\Users\\Grace.Benson001\\Desktop\\Test.txt");

    if(!InputRecord)
    {
        cout << "File not found!\n";
        return 0;   // Exit program
    }

    InputRecord >> Name >> Phone >> Email >> ZipCode>> DOB;
    while(InputRecord)
    {
        cout << ++Visitor << " - " << Name << " - " << Phone << " - " << Email << " - " << ZipCode << " - " << DOB << "\n";
        InputRecord >> Name >> Phone >> Email >> ZipCode >> DOB;
    }

    // Close input file
    InputRecord.close();

    return 0;
}
