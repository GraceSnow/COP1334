/*	Grace Benson
	Password string challenge                      	04/17/17

    This program will ask the user for a password and verify that
    the password meets certain criteria.
    -------------------------------------------------------
	INPUT					    OUTPUT
	-----					    ------
	Password                    Uppercase letter
                                Lowercase letter
                                Digit
                                Special character
	-------------------------------------------------------
*/

//*** Program preprocessors - constants, libraries, and header files
#include <iostream>				//*** cin and cout
#include <iomanip>				//*** cout manipulator options
#include <cstring>				//*** cstring data type
#include <string>               //*** string data type
#include <stdlib.h>             //*** clear screen
using namespace std;

// Prototypes
void DisplayDescription();

int main()	//*****	 BEGINNING OF THE PROGRAM LOGIC	 *****
{
	//*** Declaration and initialization of variables
	const int SIZE = 20;                    // password length
	int lower = 0, upper = 0, digit = 0, special = 0;
	char password[SIZE];

	system("cls");  //*** clear the screen

	//*** Program statements
    //*** Display description of the program
    DisplayDescription();

    //*** Request data

    cout << "Enter password: ";
    cin >> password;

    //*** Process data
    while(strlen(password) < 6 || lower < 1 || upper < 1 || digit < 1 || special < 1)
    {
        for(int x = 0; x < strlen(password); x++)
        {
            if(islower(password[x]))
                lower++;
            if(isupper(password[x]))
                upper++;
            if(isdigit(password[x]))
                digit++;
            if(ispunct(password[x]))
               {
                    if(password[x] == '!' || password[x] == '#' || password[x] == '$' || password[x] == '%' || password[x] == '&' || password[x] == '*')
                        special++;
               }
        }

        if(strlen(password) < 6 || lower < 1 || upper < 1 || digit < 1 || special < 1)
        {
            if(strlen(password) < 6)
                cout << "Password must be at least 6 characters.\n";
            if(lower < 1)
                cout << "Password must have at least 1 lowercase letter.\n";
            if(upper < 1)
                cout << "Password must have at least 1 uppercase letter.\n";
            if(digit < 1)
                cout << "Password must have at least 1 digit.\n";
            if(special < 1)
                cout << "Password must have at least 1 special character.\n";

            lower = 0;
            upper = 0;
            digit = 0;
            special = 0;

            cout << "Re-enter password: ";
            cin >> password;
        }
    }

    //*** Display results
    cout << "Password (" << password << ") has been confirmed.\n\n";

	//*** Return to the operating system
	return 0;
}	//***** 	END OF THE PROGRAM LOGIC	 *****

void DisplayDescription()
{   /*
    Displays description of program
        Parameters - none
        Return - none
        Input - none
        Output - none
    */

    cout << "This program will ask the user for a password and verify that\n";
    cout << "the password meets certain criteria.";
	cout  << "\n\n";				//*** display 2 blank lines
}