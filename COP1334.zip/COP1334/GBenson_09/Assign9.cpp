/*	Grace Benson
	Assignment #9                      	04/09/17

    This program will grade the written portion of the driver�s license exam.
    It will store the correct questions in an array and ask the user to enter
    the student�s answers, and put them in another array. The program will
    display the student�s grade, total correct answers, the total incorrect
    answers and which questions are incorrect.
    -------------------------------------------------------
	INPUT					    OUTPUT
	-----					    ------
	Student answers             Grade
                                Total incorrect answers
                                Total correct answers
	-------------------------------------------------------
*/

//*** Program preprocessors - constants, libraries, and header files
#include <iostream>				//*** cin and cout
#include <iomanip>				//*** cout manipulator options
#include <string>				//*** string datatype
#include <stdlib.h>             //*** clear screen
using namespace std;

// Prototypes
void DisplayDescription();
void getStudentAnswers(char [], const int);
int gradeAnswers(char [], char [], const int);
void DisplayGrade(int, const int, const int, char [], char []);

int main()	//*****	 BEGINNING OF THE PROGRAM LOGIC	 *****
{
	//*** Declaration and initialization of variables
	const int QUESTIONS = 20;           // Number of questions in exam
	const int MIN_CORRECT = 15;         // Must have at least 15 questions correct to pass
	int TotalIncorrect;
	char CorrectAnswers[QUESTIONS] = {'A', 'D', 'B', 'B', 'C', 'B', 'A', 'B', 'C', 'D', 'A', 'C', 'D', 'B', 'D', 'C', 'C', 'A', 'D', 'B'};
	char StudentAnswers[QUESTIONS];

	system("cls");  //*** clear the screen

	//*** Program statements
    //*** Display description of the program
    DisplayDescription();

    //*** Request data
    getStudentAnswers(StudentAnswers, QUESTIONS);
    TotalIncorrect = gradeAnswers(StudentAnswers, CorrectAnswers, QUESTIONS);

    //*** Process data and display results
    DisplayGrade(TotalIncorrect, QUESTIONS, MIN_CORRECT, StudentAnswers, CorrectAnswers);

	//*** Return to the operating system
	return 0;
}	//***** 	END OF THE PROGRAM LOGIC	 *****

void DisplayDescription()
{   /*
    Displays description of program
        Parameters - none
        Return - none
        Input - none
        Output - none
    */

    cout << "This program will grade the written portion of the driver�s license exam.\n";
    cout << "It will store the correct questions in an array and ask the user to enter\n";
    cout << "the student�s answers, and put them in another array. The program will\n";
    cout << "display the student�s grade, total correct answers, the total incorrect\n";
    cout << "answers and which questions are incorrect.";
	cout  << "\n\n";				//*** display 2 blank lines
}

void getStudentAnswers(char StudentAnswers[], const int QUESTIONS)
{   /*
    Asks user to enter student answers
        Input
            Student answers - the tester's answers that the user enters
        Parameters
            questions - number of questions in exam and size of array
    */

    for(int x = 0; x <+ QUESTIONS; x++)
    {
        cout << "Enter the student answer to #" << x + 1 << ": ";
        cin >> StudentAnswers[x];
        while(StudentAnswers[x] != 'A' && StudentAnswers[x] != 'B' && StudentAnswers[x] != 'C' && StudentAnswers[x] != 'D')
        {
            cout << "The answer must be 'A', 'B', 'C', or 'D'.\n";
            cout << "Enter student answer: ";
            cin >> StudentAnswers[x];
        }
        cout << endl;
    }
}

int gradeAnswers(char StudentAnswers[], char CorrectAnswers[], const int QUESTIONS)
{   /*
    Evaluates the student answers against the correct answers
    for the number of incorrect questions
        Parameters
            Student answers - the tester's answers
            Correct answers - the correct answers
            Questions - the number of questions on the test and the size of the array
        Returns
            Total incorrect - number of incorrect answers
    */

    int TotalIncorrect = 0;

    for(int x = 0; x < QUESTIONS; x++)
    {
        if(StudentAnswers[x] != CorrectAnswers[x])
            TotalIncorrect++;
    }

    return TotalIncorrect;
}

void DisplayGrade(int TotalIncorrect, const int QUESTIONS, const int MIN_CORRECT, char StudentAnswers[], char CorrectAnswers[])
{   /*
    Displays the grade received on the test
        Parameters
            Student answers - the tester's answers
            Correct answers - the correct answers
            Questions - the number of questions on the test and the size of the array
            Minimum correct - minimum number of correct questions needed to pass the test
        Output
            Total incorrect - number of questions incorrect
            Total correct - number of questions correct
    */

    if(TotalIncorrect >= MIN_CORRECT)
        cout << "The student has failed the test.\n\n";
    else
        cout << "The student has passed the test.\n\n";

    cout << "Total correct answers: " << QUESTIONS - TotalIncorrect << endl;
    cout << "Total incorrect answers: " << TotalIncorrect << "\n\n";

    cout << "Questions Missed:\n\n";
    for(int x = 0; x < QUESTIONS; x++)
    {
        if(StudentAnswers[x] != CorrectAnswers[x])
            cout << x + 1 << endl;
    }
}
