/*
Grace Benson
Assignment #7		                 04/01/17

This program will ask the user to enter an item's wholesale
cost and percentage, and then display the item's retail price.
-------------------------------------------------------
INPUT					    OUTPUT
-----					    ------
Wholesale cost              Retail price
Markup percentage
-------------------------------------------------------
*/

//*** Program preprocessors - constants, libraries, and header files
#include <iostream>				//*** cin and cout
#include <iomanip>				//*** cout manipulator options
#include <string>				//*** string datatype
#include <stdlib.h>             //*** clear screen

using namespace std;

// Prototypes
void DisplayDescription();
double GetWholesaleCost(double);
double GetMarkupPercent(double);
double calculateRetail(double, double);
void DisplayRetailPrice(double);

int main()	//*****	 BEGINNING OF THE PROGRAM LOGIC	 *****
{
	//*** Declaration and initialization of variables
	double WholesaleCost, MarkupPercent, RetailPrice;

	system("cls");  //*** clear the screen

    //*** Display description of the program
    DisplayDescription();

    //*** Request data
    WholesaleCost = GetWholesaleCost(WholesaleCost);
    MarkupPercent = GetMarkupPercent(MarkupPercent);

    //*** Process data
    RetailPrice = calculateRetail(WholesaleCost, MarkupPercent);

	//*** Display results
    DisplayRetailPrice(RetailPrice);

	//*** Return to the operating system
	return 0;
}	//***** 	END OF THE PROGRAM LOGIC	 *****

void DisplayDescription()
{    /*
        Displays description of program
            Parameters - none
            Return - none
    */

    cout  << "This program will ask the user to enter an item's wholesale cost\n";
    cout << "and percentage, and then display the item's retail price.\n\n";
}

double GetWholesaleCost(double WholesaleCost)
{    /*
        Asks the user for the wholesale cost of an item and validates
        that it is not negative
            Returns
                Wholesale Cost - wholesale cost of an item
    */

    cout << "Enter the item's wholesale cost: ";
    cin >> WholesaleCost;
    while(WholesaleCost < 0)
    {
        cout << "Error: The wholesale cost cannot be negative.\n";
        cout << "Enter another number: ";
        cin >> WholesaleCost;
    }

    return WholesaleCost;
}

double GetMarkupPercent(double MarkupPercent)
{    /*
        Asks the user for the markup percentage of an item and validates
        that it is not negative
           Returns
                Markup Percent - markup percentage of the item
    */

    cout << "Enter the item's markup percentage: ";
    cin >> MarkupPercent;
    while(MarkupPercent < 0)
    {
        cout << "Error: The markup percentage cannot be negative.\n";
        cout << "Enter another number: ";
        cin >> MarkupPercent;
    }

    return MarkupPercent;
}

double calculateRetail(double WholesaleCost, double MarkupPercent)
{    /*
        Calculates the retail price of the item from its wholesale
        cost and markup percentage
            Parameters
                Wholesale Cost - wholesale cost of item
                Markup Percent - markup percent of item
            Returns
                Retail Price - Retail Price of item
    */

    return (WholesaleCost * MarkupPercent) + WholesaleCost;
}

void DisplayRetailPrice(double RetailPrice)
{   /*
        Displays the retail price of the item
            Parameters
                Retail Price - retail price of item
    */

    cout << "The retail price of the item is $" << RetailPrice << ".";
}
