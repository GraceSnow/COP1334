/*
Program to demonstrate the use of functions
The program will display a Greeting
*/

#include <iostream>
#include <stdlib.h>

using namespace std;

// Prototypes
void Greeting();        // Displays a greeting
void GreetingX(int);    // Displays greeting x number of times
int GreetingXY(int);   // Displays greeting x number of times and returns -99

// Beginning of program
int main()
{
    int x;

    Greeting();
    cin.get();

    GreetingX(5);
    cin.get();

    GreetingXY(3);
    cin.get();
    cout << GreetingXY(3);
    cout << 100 - GreetingXY(4);
    cin.get();
    x = GreetingXY(3);
    cout << x;

    return 0;
}
// End of program

// Functions
void Greeting()
{
    /*
    Clears screen and displays a greeting
        Parameters - none
        Returns - none
        Input - none
        Output - none
    */

    //system("cls");
    cout << "Hello world!" << endl;
}

void GreetingX(int RepetitionValue)
{
    /*
    Displays a greeting X number of times
        Parameters
            RepetitionValue - number of time to display greeting
        Returns - none
        Input - none
        Output - none
    */

    //system("cls");
    for(int x = 0; x < RepetitionValue; x++)
        cout << "Hello world!" << endl;
}

int GreetingXY(int RepetitionValue)
{
    /*
    Displays a greeting X number of times
        Parameters
            RepetitionValue - number of time to display greeting
        Returns
            -99
        Input - none
        Output - none
    */

    //system("cls");
    for(int x = 0; x < RepetitionValue; x++)
        cout << "Hello world!" << endl;

    return -99;
}
