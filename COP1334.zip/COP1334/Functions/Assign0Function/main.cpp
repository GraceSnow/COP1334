/*	Iama C. Plusplus-Student		Student #R1234567
	Problem #0 - Assignment #0		Due Date 01/15/08

	This program will calculate the average sales of
	a two week period.
	-------------------------------------------------------
	INPUT					    OUTPUT
	-----					    ------
	Salesperson's name		    Salesperson's name
	Sales for week 1			    Average Sales
	Sales for week 2
	-------------------------------------------------------
*/

//*** Program preprocessors - constants, libraries, and header files
#include <iostream>				//*** cin and cout
#include <iomanip>				//*** cout manipulator options
#include <string>				//*** string datatype
#include <stdlib.h>             //*** clear screen
using namespace std;

// Prototypes
void DescriptionOfProgram();
float CalculateTotalSales(int, int);
void DisplayResult(string, float);
void GetInput(string&, int&, int&);

int main()	//*****	 BEGINNING OF THE PROGRAM LOGIC	 *****
{
	//*** Declaration and initialization of variables
	string salesperson;
	int week1_sales, week2_sales;
	double average;

	system("cls");  //*** clear the screen

	//*** Program statements
    //*** Display description of the program
    DescriptionOfProgram();

    //*** Request data
    GetInput(salesperson, week1_sales, week2_sales);

    //*** Process data
	average = CalculateTotalSales(week1_sales, week2_sales);

	//*** Display results
    DisplayResult(salesperson, average);

	//*** Return to the operating system
	return 0;
}	//***** 	END OF THE PROGRAM LOGIC	 *****

void DescriptionOfProgram()
{
    /*
        Displays description of program

            Parameters - none
            Return - none
            Input - none
            Output - none
    */

    cout  << "This program will calculate the average sales\n";
	cout  << "of a two week period. \n";
	cout  << "\n\n";				//*** display 2 blank lines
}

float CalculateTotalSales(int WeekSales1, int WeekSales2)
{
    /*
        Calculates the average sales of 2 weeks

            Parameters
                WeekSales1 - sales for week 1
                WeekSales2 - sales for week 2
            Returns
                Average - average of the 2 weeks
    */

    //int Average;

    //Average = (WeekSales1 + WeekSales2)/2;

    return (WeekSales1 + WeekSales2)/2.0;

}

void DisplayResult(string Salesperson, float Average)
{
    /*
        Displays the average sales for salesperson
            Parameters
                Salesperson - name of salesperson
                Average - average sales of salesperson
    */

    cout << showpoint << fixed;
	cout  << "\nThe average sales for " << Salesperson
		<< " is $" << setw(7) << setprecision(2) << Average << "." << endl;
}

void GetInput(string &Name, int &WeekSales1, int &WeekSales2)
{
    /*
        Get user input of the salesperson's name and sales for week 1 and 2
            Parameters
                Name - Name of salesperson
                WeekSales1 - Sales for week 1
                WeekSales2 - Sales for week 2
    */

    cout  << "Enter the salesperson's name? ";
	cin   >> Name;
	cout  << "Enter the sales amount for week 1? ";
	cin   >> WeekSales1;
	cout  << "Enter the sales amount for week 2? ";
	cin   >> WeekSales2;
}
