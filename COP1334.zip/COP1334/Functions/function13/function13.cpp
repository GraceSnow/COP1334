#include <iostream>
#include <stdlib.h>

using namespace std;

// Prototypes
void DisplayDescription();
int GetNumber();
void CompareNumbers(int, int&, int&);
void DisplayResults(int, int, int, int);

int main()
{
    int Lowest = 999, Highest = 0, Sum = 0;
    int Counter = 0;
    int Number;

    system("cls");

    DisplayDescription();
    Number = GetNumber();
    while(Number != -99)
    {
        CompareNumbers(Number, Lowest, Highest);
        Sum += Number;
        Counter++;
        Number = GetNumber();
    }

    DisplayResults(Lowest, Highest, Counter, Sum);

    return 0;
}

// Functions
void DisplayDescription()
{
    /*
    Displays a description of the program.
    */
    cout << "This program will allow the user to enter numbers until -99 is entered.\n";
    cout << "The program will then display the lowest and highest numbers, total numbers\n";
    cout << "entered and the.\n\n";
}

int GetNumber()
{
    /*
    Allows the user to enter a positive integer.
        Returns - an integer
    */
    int Number;

    cout << "Enter a number > 0 or -99 to terminate entries: ";
    cin >> Number;
    while(Number < 1 && Number != -99)
    {
        cout << "The number must be greater than 0 or -99 to terminate entries.\n";
        cout << "Please enter number. ";
        cin >> Number;
    }

    return Number;
}

void CompareNumbers(int Number, int &Low, int &High)
{
    /*
    Evaluates for the highest and lowest number.
        Parameters
            Number - number to check
            Low - Lowest number
            High - Highest number
        Returns
            Low
            High
    */

    if(Number < Low)
        Low = Number;
    if(Number > High)
        High = Number;
}
void DisplayResults(int Low, int High, int Count, int Total)
{
    /*
    Displays low, high, count, and total.
    */
    cout << "Lowest Number: " << Low << endl;
    cout << "Highest Number: " << High << endl;
    cout << "Total numbers entered: " << Count << endl;
    cout << "Sum of the numbers: " << Total << endl;
}
