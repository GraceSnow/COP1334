/*	Grace Benson		Student #R1234567
	Homework Assignment #1		Date 01/25/08

	This program will produce a report on daily profits from ticket sales.
	-------------------------------------------------------
	INPUT						    OUTPUT
	-----						    ------
	Movie Name                      Movie Name
	Number of Adult Tickets         Number of Adult Tickets Sold
	Number of Child Tickets         Number of Child Tickets Sold
                                    Gross Box Office Profit
                                    Net Box Office Profit
                                    Amount Paid to Distributor
	-------------------------------------------------------
*/

//*** Program preprocessors - constants, libraries, and header files
#include <iostream>					//*** cin and cout
#include <iomanip>					//*** cout manipulator options
#include <string>					//*** string datatype
using namespace std;

int main()	//*****	 BEGINNING OF THE PROGRAM LOGIC	 *****
{
	const double ADULT_TICKET_PRICE = 10.00, KID_TICKET_PRICE = 6.00;
    double adult_profit, kid_profit, gross_profit, net_profit, amount_distributor;
    int num_adult_tickets, num_kid_tickets;
    string movie;

	cout << "This program will produce a report on daily profits from ticket sales.\n\n";

	cout << "Enter movie name: ";
	cin >> movie;
	cout << "Enter the number of adult tickets sold: ";
	cin >> num_adult_tickets;
	cout << "Enter the number of child tickets sold: ";
	cin >> num_kid_tickets;

	cout << "\n\n\n";

	adult_profit = num_adult_tickets * ADULT_TICKET_PRICE;
	kid_profit = num_kid_tickets * KID_TICKET_PRICE;
	gross_profit = adult_profit + kid_profit;
	net_profit = gross_profit * 0.20;
	amount_distributor = gross_profit - net_profit;

    cout << fixed << setprecision(2);
	cout << "Movie Name: " << '"' << movie << '"' << endl;
	cout << left << setw(28) << "Adult Tickets Sold: " << right << setw(10) << num_adult_tickets << endl;
	cout << left << setw(28) << "Child Tickets Sold: " << right << setw(10) << num_kid_tickets << endl;
	cout << left << setw(28) << "Gross Box Office Profit: " << right << setw(10) << gross_profit << endl;
	cout << left << setw(28) << "Net Box Office Profit: "  << right << setw(10) << net_profit << endl;
	cout << left << setw(28) << "Amount Paid to Distributor: " << right << setw(10) << amount_distributor << endl;

	return 0;
}	//***** 	END OF THE PROGRAM LOGIC	 *****
