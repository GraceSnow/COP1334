#include <iostream>
#include <stdlib.h>
#include <iomanip>

using namespace std;

int main()
{
    int floors, rooms, occupied_rooms;
    double total_rooms = 0, total_occupied_rooms = 0, total_unoccupied_rooms;
    int percent_occupied_rooms;

    system("cls");
    cout << "This program will calculate the occupancy rate for a hotel. \n\n";

    cout << "How many floors does the hotel have? ";
    cin >> floors;
    while(floors < 1)
        {
            cout << "The number of floors cannot be less than 1.\n";
            cout << "How many floors does the hotel have? ";
            cin >> floors;
        }
    cout << endl;

    for(int x = 1; x <= floors; x++)
    {
        if(x != 13) //while(x != 13 && x <= floors)
        {
            cout << "How many rooms does the hotel have on floor #" << x << " ? ";
            cin >> rooms;
            while(rooms < 10)
            {
                cout << "The number of rooms cannot be less than 10.\n";
                cout << "How many rooms are one floor #" << x << " ? ";
                cin >> rooms;
                cout << endl;
            }

        cout << "How many rooms are occupied on floor #" << x << " ? ";
        cin >> occupied_rooms;
        cout << endl;
        //x++;
        }

        total_rooms += rooms;
        total_occupied_rooms += occupied_rooms;
    }

    percent_occupied_rooms = (total_occupied_rooms / total_rooms) * 100;
    total_unoccupied_rooms = total_rooms - total_occupied_rooms;

    cout << "The total number of rooms the hotel has is " << total_rooms << ".\n";
    cout << "The total number of occupied rooms in the hotel is " << total_occupied_rooms << ".\n";
    cout << "The total number of unoccupied rooms in the hotel is " << total_unoccupied_rooms << " .\n";
    cout << "The percentage of rooms that are occupied is " << percent_occupied_rooms << "% .";

    return 0;
}
