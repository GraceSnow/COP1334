#include <iostream>

using namespace std;

// creates a variable
struct Person   // data type
{
    string Name;
    int Grade;
}Student;       // name of data type

void GetData(Person [], int);
void DisplayData(Person [], int);

int main()
{
    Person Student[5];

    GetData(Student, 5);

    DisplayData(Student, 5);

    return 0;
}

void GetData(Person Student[], int Size)
{
    for(int x = 0; x < Size; x++)
    {
        cout << "Enter name for student " << x + 1 << ": ";
        cin >> Student[x].Name;
        cout << "Enter grade: ";
        cin >> Student[x].Grade;
    }
}

void DisplayData(Person Student[], int Size)
{
    for(int x = 0; x < Size; x++)
        cout << Student[x].Name << "-" << Student[x].Grade << "\n\n";
}
