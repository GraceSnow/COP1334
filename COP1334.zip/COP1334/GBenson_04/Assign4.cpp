/*	Grace Benson
	Homework Assignment #4

	This program will calculates the balance of a savings account at the
	end of a period of time and display the balance, the total amount of
	deposits, the total amount of withdrawals, and the total interest
	earned in a savings account.
	-------------------------------------------------------
	INPUT						    OUTPUT
	-----						    ------
	Balance                         Balance
	Annual interest rate            Total amount of deposits
	Number of Months                Total amount of withdrawals
    Amount deposited                Total interest earned
    Amount withdrawn
    Monthly interest
    Monthly interest rate
	-------------------------------------------------------
*/

//*** Program preprocessors - constants, libraries, and header files
#include <iostream>					//*** cin and cout
#include <iomanip>					//*** cout manipulator options
#include <string>					//*** string datatype
#include <stdlib.h>

using namespace std;

int main()
{
    double Balance, AnnualInterestRate, AmountDeposited, AmountWithdrawn;
    double TotalWithdrawn = 0, TotalDeposited = 0, TotalInterestEarned = 0, MonthlyInterest=0;
    int Months;

    system("cls");
    cout << "This program will calculates the balance of a savings account at the end of a \n";
    cout << "period of time and display the balance, the total amount of deposits, the \n";
    cout << "total amount of withdrawals, and the total interest earned in a savings account.\n\n";

    cout << "Enter the annual interest rate of the account: ";
    cin >> AnnualInterestRate;

    cout << "\nEnter the starting balance of the account: ";
    cin >> Balance;

    cout << "\nEnter the number of months that have passed since the account\n";
    cout << "was established: ";
    cin >> Months;
    cout << endl << endl;

    for(int x = 1; x <= Months; x++)
    {
        cout << "\nEnter the amount deposited into the account during the month: ";
        cin >> AmountDeposited;
        while(AmountDeposited < 0)
        {
            cout << "\nThe amount deposited cannot be a negative amount.\n";
            cout << "Enter the amount deposited into the account during the month: ";
            cin >> AmountDeposited;
        }

        cout << "\nEnter the amount withdrawn from the account during the month: ";
        cin >> AmountWithdrawn;
        while(AmountWithdrawn < 0)
        {
            cout << "\nThe amount withdrawn cannot be a negative amount.\n";
            cout << "Enter the amount withdrawn from the account during the month: ";
            cin >> AmountWithdrawn;
        }

        Balance += AmountDeposited - AmountWithdrawn;
        MonthlyInterest = (AnnualInterestRate / 12) * Balance;
        Balance += MonthlyInterest;

        if(Balance < 0)
            {
                cout << "\n\nThe account balance is negative.\n\n";
                break;
            }

        TotalWithdrawn += AmountWithdrawn;
        TotalDeposited += AmountDeposited;
        TotalInterestEarned += MonthlyInterest;
    }

    cout << "\n\nAccount Balance: " << setw(4) << setprecision(2) << fixed << right << Balance;
    cout << "\nTotal Deposits: " << setw(4) << setprecision(2) << fixed << right << TotalDeposited;
    cout << "\nTotal Withdrawn: " << setw(4) << setprecision(2) << fixed << right << TotalWithdrawn;
    cout << "\nTotal Interest Earned: " << setw(4) << setprecision(2) << fixed << right << TotalInterestEarned;

    return 0;
}
