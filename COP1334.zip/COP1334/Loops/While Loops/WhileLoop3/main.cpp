// Data validation and user supplied data for loop.

#include <iostream>     // input and output statements
#include <stdlib.h>     // clear screen

using namespace std;

int main()
{
    short int grade, NumGrades, TotalGrade=0, AverageGrade=0;
    int total=0, counter=0;

    cout << "Program will display total grades and average.\n\n";

    cout << "How many grades will be entered? ";
    cin >> NumGrades;

    while(++counter <= NumGrades)
    {
        cout << "Enter grade: ";
        cin >> grade;
        while(grade < 0 || grade > 100)     //evaluating grade to ensure grade is between 0 and 100
        {
            cout << "\nThe grade entered was incorrect. Please enter a grade between 0 and 100." << endl;

            cout << "Enter grade" << counter << ": ";
            cin >> grade;
        }
        total += grade;
    }
    //cout << endl << "Counter: " << counter << endl;

    //AverageGrade = TotalGrade/--counter;

    cout << "Total Points: " << total << endl;
    //cout << endl << "Average Grade: " << AverageGrade << endl;
    cout << "Grade Average: \" " << static_cast<double> (total)/NumGrades << endl;

    return 0;
}
