// Sentinel entry and data validation

#include <iostream>     // input and output statements

using namespace std;

int main()
{
    short int grade, NumGrades, TotalGrade=0, AverageGrade=0;
    int total=0, counter=1;

    cout << "Program will display total grades and average.\n\n";

    cout << "Enter Grade 1: or enter -1 to terminate program. ";
    cin >> NumGrades;
    //cout << "How many grades will be entered? ";
    //cin >> NumGrades;

    while(grade != -1)
    {
        while(grade < 0 || grade > 100)     //evaluating grade to ensure grade is between 0 and 100
        {
            cout << "\nThe grade entered was incorrect. Please enter a grade between 0 and 100." << endl;

            cout << "Enter grade #" << ++counter << ": ";
            cin >> grade;
        }

        total += grade;

        cout << "Enter grade: ";
        cin >> grade;
    }
    //cout << endl << "Counter: " << counter << endl;

    //AverageGrade = TotalGrade/--counter;

    cout << "Total Points: " << total << endl;
    //cout << endl << "Average Grade: " << AverageGrade << endl;
    cout << "Grade Average: \" " << static_cast<double> (total)/(counter-1) << "\"";

    return 0;
}
