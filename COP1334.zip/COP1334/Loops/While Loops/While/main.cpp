#include <iostream>

using namespace std;

int main()
{
    short int grade, NumGrades, TotalGrade=0, AverageGrade=0;
    short int counter=0;

    cout << "Enter grade of -1 to end: ";
    cin >> grade;

    while(grade != -1)
    {
        TotalGrade += grade;
        counter++;

        cout << "Enter grade or -1 to end: ";
        cin >> grade;
    }
    //cout << endl << "Counter: " << counter << endl;

    //AverageGrade = TotalGrade/--counter;

    cout << "Total Grade: " << TotalGrade << endl;
    //cout << endl << "Average Grade: " << AverageGrade << endl;
    cout << "Average Grade: " << static_cast <double> (TotalGrade)/counter << endl;

    return 0;
}
