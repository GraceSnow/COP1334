#include <iostream>
#include <stdlib.h>

using namespace std;

int main()
{
    short int counter = 1, numlimit;
    int total = 0;

    system("cls");
    cout << "This program will sum the numbers between 1 and the limit supplied by the user." << endl;

    cout << "Enter limit: ";
    cin >> numlimit;
    while (numlimit < 1)
    {
        cout << "The limit must be greater than 0. Please enter limit: ";
        cin >> numlimit;
    }

    while(counter <= numlimit)
    {
        total += counter;
        ++counter;
    }
     /*for(counter = 1; counter <= numlimit; ++counter)
    {
        total += counter;
    }

     for(int x = 1; x <= numlimit; ++x)
    {
        total += x;
    }*/


    cout << "Total: " << total << endl;

    return 0;
}
