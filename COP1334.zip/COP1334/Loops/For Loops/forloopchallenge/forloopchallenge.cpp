#include <iostream>

using namespace std;

int main()
{
    cout << "this program displays Pattern A and Pattern B.\n\n";

    for(int row = 0; row < 10; row++)
    {
        for(int row1 = 0; row1 < row; row1++)
            cout << "+";
        for(int col = 10; col > row; col--)
            cout << " ";
        for(int col1 = 10; col1 > row; col1--)
            cout << "+";
        cout << endl;
    }

    return 0;
}
