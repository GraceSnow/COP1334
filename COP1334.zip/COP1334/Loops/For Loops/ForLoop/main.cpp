#include <iostream>

using namespace std;

int main()
{
    int counter=55;

    for(int x = 0; x < NumGrades; x+=5)
        cout << x << ". Hello world!" << endl;

    cout << "\n\nThe value of counter is " << counter << endl;

    return 0;
}
