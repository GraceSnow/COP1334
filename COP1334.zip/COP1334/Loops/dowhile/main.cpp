// Sentinel entry and data validation

#include <iostream>     // input and output statements

using namespace std;

int main()
{
    short int grade, TotalGrade=0, AverageGrade=0;
    int total=0, counter=1;
    char answer;

    cout << "Program will display total grades and average.\n\n";

    do
    {
        cout << "Enter Grade #" << counter++ << " or enter -1 to terminate program. ";
        cin >> grade;

        while(grade < 0 || grade > 100)     //evaluating grade to ensure grade is between 0 and 100
        {
            cout << "The grade entered was incorrect. Please enter a grade between 0 and 100. ";
            cin >> grade;
        }

        total += grade;

        cout << "Do you have another grade? (Y/N) ";
        cin >> answer;
    }while (answer == 'Y');

    //cout << endl << "Counter: " << counter << endl;

    //AverageGrade = TotalGrade/--counter;

    cout << "Total Points: " << total << endl;
    //cout << endl << "Average Grade: " << AverageGrade << endl;
    cout << "Grade Average: \"" << static_cast<double> (total)/(counter-1) << "\"";

    return 0;
}
