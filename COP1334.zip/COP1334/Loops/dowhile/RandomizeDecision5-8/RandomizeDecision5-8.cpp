#include <iostream>
#include <cstdlib>      // Library for randomizing numbers - rand()
                        // int rand()
#include <ctime>        // Library for acquiring the system time
                        // since January 1, 1970 in seconds
                        // int time()

using namespace std;

int main()
{
    const int MaximumValue = 150;
    const int MinimumValue = 100;
    int NumberGenerated;
    int UserGuess;

    NumberGenerated = rand() + time(0);
    cout << "Number generated: " << NumberGenerated << endl;

    NumberGenerated = ((rand() + time(0)) % (MaximumValue - MinimumValue + 1)) + MinimumValue;
    cout << "Number generated: " << NumberGenerated << endl;

    cout << "Press a key to continue.\n";
    cin.get();  // Used to pause the screen. User must press ENTER to continue

    do
    {
        cout << "Guess what the generated number is: " << endl;
        cin >> UserGuess;

        if(UserGuess == NumberGenerated)
            cout << "Congratulations! You guessed the correct number!\n";
        else if(UserGuess > NumberGenerated)
            cout << "Your guess is too high. Try again.\n";
        else
            cout << "Your guess is too low. Try again.\n";
    }while(UserGuess != NumberGenerated);

    cout << "\n";

    return 0;
}
