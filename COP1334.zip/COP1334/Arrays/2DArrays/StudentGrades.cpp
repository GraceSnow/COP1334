/*	Grace Benson
	Programming Challenge 1 - Arrays	03/27/17

	This program lets the user enter the name of a student
	and their grade into a 2D array. The program should
	then display the largest and smallest
	grades of the students stored in the array.
	-------------------------------------------------------
	INPUT					    OUTPUT
	-----					    ------
	10 numbers                  Largest Number
                                Smallest Number
	-------------------------------------------------------
*/

//*** Program preprocessors - constants, libraries, and header files
#include <iostream>				//*** cin and cout
#include <iomanip>				//*** cout manipulator options
#include <string>				//*** string datatype
#include <stdlib.h>             //*** clear screen
using namespace std;

// Prototypes
void DisplayDescription();
void GetNumbers(int, int []);    // Empty [] to indicate an array
                                // Address of array is passed to function, thus values
                                // are passed by reference
int FindSmallest(int, int []);
int FindLargest(int, int []);
void DisplaySmallestLargest(int, int);
int SmallestPosition(int, int []);
int LargestPosition(int, int []);
void DisplayAverage(int, int []);
//void DisplaySum(int, int []);

int main()	//*****	 BEGINNING OF THE PROGRAM LOGIC	 *****
{
	//*** Declaration and initialization of variables
	const int STUDENT_SIZE = 5;
	string Names[STUDENT_SIZE];
	int Grades[STUDENT_SIZE];
	int HighestGrade, LowestGrade;

	system("cls");  //*** clear the screen

	//*** Program statements
    //*** Display description of the program
    DisplayDescription();

    //*** Request data
    //GetNumbers(SIZE, Numbers);  // Only use the name of the array
                                // Do not include brackets []
    for(int x = 0; x < STUDENT_SIZE; x++)
    {
        cout << "Name of student " << x+1 << ": ";
        cin >> Names[x];
        cout << "Ender the grade for " << Names[x] << ": ";
        cin >> Grades[x];
        cout << "\n";
    }

    //*** Process data
    /*
    Smallest = FindSmallest(SIZE, Numbers);
    Largest = FindLargest(SIZE, Numbers);
    */
    HighestGrade = FindLargest(STUDENT_SIZE, Grades);
    LowestGrade = FindSmallest(STUDENT_SIZE, Grades);

    //*** Display results
    cout << "The highest grade is: " << Names[LargestPosition(STUDENT_SIZE, Grades)] << HighestGrade << endl;
    cout << "The lowest grade is: " << Names[SmallestPosition(STUDENT_SIZE, Grades)] << LowestGrade << endl;
    cout << endl;

    DisplayAverage(STUDENT_SIZE, Grades);
    //DisplaySmallestLargest(HighestGrade, LowestGrade);
    //DisplaySum(SIZE, Numbers);

	//*** Return to the operating system
	return 0;
}	//***** 	END OF THE PROGRAM LOGIC	 *****

void DisplayDescription()
{
    /*
        Displays description of program

            Parameters - none
            Return - none
            Input - none
            Output - none
    */

    cout << "This program lets the user enter the name of a student and their grade\n";
    cout << "into a 2D array. The program should then display the largest and smallest\n";
    cout << "grades of the students stored in the array.\n\n";
}

void GetNumbers(int Size, int Numbers[])     // Identifier and [] indicate an array
{                                            // Array address is passed to the function
    /*
        Get numbers to evaluate for smallest and largest
            Parameters
                Size - size of array
            Returns
                Numbers - elements in array
    */

    for(int x = 0; x < Size; x++)
    {
        cout << x+1 << ". Enter a number: ";
        cin >> Numbers[x];
    }

}

int FindSmallest(int Size, int Numbers[])
{
    /*
        Evaluate Numbers array for the smallest
            Parameters
                size - size of array
            Returns
                Smallest - smallest number
    */

    int Smallest;
    Smallest = Numbers[0];
    for(int x = 0; x < Size; x++)
    {
        if(Numbers[x] < Smallest)
            Smallest = Numbers[x];
    }

    return Smallest;
}

int FindLargest(int Size, int Numbers[])
{
    /*
        Evaluate Numbers array for the smallest
            Parameters
                size - size of array
            Returns
                Smallest - smallest number
    */

    int Largest;
    Largest = Numbers[0];
    for(int x = 0; x < Size; x++)
    {
        if(Numbers[x] > Largest)
            Largest = Numbers[x];
    }

    return Largest;
}
/*
void DisplaySmallestLargest(int Smallest, int Largest, int Grades[], int Size)
{
    /*
    Display the smallest and largest numbers
            Parameters - none
            Return - none
            Input - none
            Output - none
    */
/*
    cout << "The highest grade is: " << Names[SmallestPosition(Grades, Size)] << Largest << endl;
    cout << "The lowest grade is: " << Names[SmallestPosition(Grades, Size) << Smallest << endl;
    cout << endl;
}
*/

int SmallestPosition(int Size, int Numbers[])
{
    /*
        Evaluate Numbers array for the smallest
            Parameters
                size - size of array
            Returns
                Smallest - smallest number
    */

    int Position = 0;
    int Smallest = Numbers[0];
    for(int x = 1; x < Size; x++)
    {
        if(Numbers[x] < Smallest)
            Position = x;
    }

    return Position;
}

int LargestPosition(int Size, int Numbers[])
{
    /*
        Evaluate Numbers array for the smallest
            Parameters
                size - size of array
            Returns
                Smallest - smallest number
    */

    int Position = 0;
    int Largest = Numbers[0];
    for(int x = 1; x < Size; x++)
    {
        if(Numbers[x] > Largest)
            Position = x;
    }

    return Position;
}

void DisplayAverage(int Size, int Numbers[])
{
    int Sum = 0;
    double Average;
    for(int x = 0; x < Size; x++)
        Sum += Numbers[x];

    Average = Sum / Size;

    cout << "The average is " Average << ".\n";

}
/*
void DisplaySum(int Size, int Numbers[])
{
    int Sum = 0;
    for(int x = 0; x < Size; x++)
        Sum += Numbers[x];

    cout << "The sum of the numbers is " << Sum << ".\n";
}
*/
