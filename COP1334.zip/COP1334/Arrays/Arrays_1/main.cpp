/*	Grace Benson
	Programming Challenge 1 - Arrays	03/27/17

	This program lets the user enter 10 values into an array.
	The program should then display the largest and smallest
	values stored in the array.
	-------------------------------------------------------
	INPUT					    OUTPUT
	-----					    ------
	10 numbers                  Largest Number
                                Smallest Number
	-------------------------------------------------------
*/

//*** Program preprocessors - constants, libraries, and header files
#include <iostream>				//*** cin and cout
#include <iomanip>				//*** cout manipulator options
#include <string>				//*** string datatype
#include <stdlib.h>             //*** clear screen
using namespace std;

// Prototypes
void DisplayDescription();
void GetNumbers(int, int []);    // Empty [] to indicate an array
                                // Address of array is passed to function, thus values
                                // are passed by reference
int FindSmallest(int, int []);
int FindLargest(int, int []);
void DisplaySmallestLargest(int, int);
void DisplaySum(int, int []);

int main()	//*****	 BEGINNING OF THE PROGRAM LOGIC	 *****
{
	//*** Declaration and initialization of variables
	int SIZE = 10;
	int Numbers[SIZE];
	int Smallest, Largest;

	system("cls");  //*** clear the screen

	//*** Program statements
    //*** Display description of the program
    DisplayDescription();

    //*** Request data
    GetNumbers(SIZE, Numbers);  // Only use the name of the array
                                // Do not include brackets []
    //*** Process data
    Smallest = FindSmallest(SIZE, Numbers);
    Largest = FindLargest(SIZE, Numbers);
	//*** Display results
    DisplaySmallestLargest(Smallest, Largest);
    DisplaySum(SIZE, Numbers);
	//*** Return to the operating system
	return 0;
}	//***** 	END OF THE PROGRAM LOGIC	 *****

void DisplayDescription()
{
    /*
        Displays description of program

            Parameters - none
            Return - none
            Input - none
            Output - none
    */

    cout << "This program lets the user enter 10 values into an array. The program\n";
    cout << "should then display the largest and smallest values stored in the array.";
	cout  << "\n\n";				//*** display 2 blank lines
}

void GetNumbers(int Size, int Numbers[])     // Identifier and [] indicate an array
{                                            // Array address is passed to the function
    /*
        Get numbers to evaluate for smallest and largest
            Parameters
                Size - size of array
            Returns
                Numbers - elements in array
    */

    for(int x = 0; x < Size; x++)
    {
        cout << x++ << ". Enter a number: ";
        cin >> Numbers[x];
    }

}

int FindSmallest(int Size, int Numbers[])
{
    /*
        Evaluate Numbers array for the smallest
            Parameters
                size - size of array
            Returns
                Smallest - smallest number
    */

    int Smallest;
    Smallest = Numbers[0];
    for(int x = 0; x < Size; x++)
    {
        if(Numbers[x] < Smallest)
            Smallest = Numbers[x];
    }

    return Smallest;
}

int FindLargest(int Size, int Numbers[])
{
    /*
        Evaluate Numbers array for the smallest
            Parameters
                size - size of array
            Returns
                Smallest - smallest number
    */

    int Largest;
    Largest = Numbers[0];
    for(int x = 0; x < Size; x++)
    {
        if(Numbers[x] > Largest)
            Largest = Numbers[x];
    }

    return Largest;
}

void DisplaySmallestLargest(int Smallest, int Largest)
{
    /*
    Display the smallest and largest numbers
            Parameters - none
            Return - none
            Input - none
            Output - none
    */

    cout << "The smallest number is " << Smallest << ".\n";
    cout << "The Largest number is " << Largest << ".\n";
}

void DisplaySum(int Size, int Numbers[])
{
    int Sum = 0;
    for(int x = 0; x < Size; x++)
        Sum += Numbers[x]
    
    cout << "The sum of the numbers is " << Sum << ".\n";
}
