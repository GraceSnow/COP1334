#include <iostream>
#include <string>
#include <cstring>
//#include <cstdlib>
//#include <cctype>

using namespace std;

void SizeofStringArrays(string [], char [][15]);

int main()
{
    string Phrase;
    char CPhrase[15];

//    // sizeof() returns the size in bytes of what is passed to it
//    cout << sizeof(int) << sizeof(long) << sizeof(float) << sizeof(double) << sizeof(char) << sizeof(Phrase) << sizeof(CPhrase);
//    return 0;
//    //*** Entering data into and displaying the contents of a string
//    cout << "Enter value for Phrase: ";
//    cin >> Phrase;
//    cout << "Enter value for CPhrase: ";
//    cin >> CPhrase;
//
//    cout << "Phrase: " << Phrase << "\n";
//    cout << "CPhrase: " << CPhrase << "\n";
//    cout << "\n";

//    //*** Display the length and the size in memory of each string
//    cout << "Length of Phrase: " << Phrase.length() << "\n";
//    cout << "Length of CPhrase: " << strlen(CPhrase) << "\n\n";
//
//    cout << "Size of Phrase: " << sizeof(Phrase) << "\n";
//    cout << "Size of CPhrase: " << sizeof(CPhrase) << "\n\n";

//    //*** Entering and Accepting spaces and tabs in a string
//    //*** to accept spaces or tabs in a string use getline() and get()
//    cin.ignore();
//    cout << "Enter value for Phrase: ";
//    getline(cin, Phrase);
//    cout << "Enter value for CPhrase: ";
//    cin.get(CPhrase, 15);
//
//    cout << "Phrase: " << Phrase << " - " << Phrase.length() << "\n";
//    cout << "CPhrase: " << CPhrase << " - " << strlen(CPhrase)  << "\n";
//    cout << "\n";
//
//    //*** Display a string, 1 character at a time
//    for(int x=0; x < Phrase.length(); x++)
//        cout << Phrase[x] << "-";
//    cout << "\n";
//
//    for(int x=0; x < strlen(CPhrase); x++)
//        cout << CPhrase[x] << "-";
//    cout << "\n\n";


//    //***  Assigning values to strings
//    Phrase = "Hello World";
//    strcpy(CPhrase, "Hello World");
//
//    cout << "Phrase: " << Phrase << "\n";
//    cout << "CPhrase: " << CPhrase << "\n";
//    cout << "\n";
//
    //*** Counting the number of times a character appears in a string
    //*** counting the number of times 'l' occurs in a string
//    int y = 0;
//    for(int x=0; x < Phrase.length(); x++)
//    {
//        if (Phrase[x] == 'l')
//            y++;
//    }
//    cout << "The number of L's in String is: " << y << "\n";
//
//    y = 0;
//    for(int x=0; x < strlen(CPhrase); x++)
//    {
//        if (CPhrase[x] == 'l')
//            y++;
//    }
//    cout << "The number of L's in C String is: " << y << "\n\n";

//    //*** Replacing characters of a string
//    //*** replacing each occurrence of the character 'l' with '*'
//    for(int x=0; x < Phrase.length(); x++)
//    {
//        if (Phrase[x] == 'l')
//            Phrase[x] = '*';
//    }
//    cout << "The new String Phrase is : " << Phrase << "\n";
//
//    for(int x=0; x < strlen(CPhrase); x++)
//    {
//        if (CPhrase[x] == 'l')
//            CPhrase[x] = '*';
//    }
//    cout << "The new C String CPhrase is: " << CPhrase << "\n";

//    //*** Comparing Stings and C-Strings
//    //***Strings
//    cout << "\n\n Stings\n\n";
//    string ComparePhrase = "Hello World 2";
//    string String[] = {"Hello World 1", "Hello World 2", "Hello World 3"};
//    int StringRows;
//
//    cout << "The number of bytes of String are " << sizeof(String) << "\n";
//    StringRows = sizeof(String)/sizeof(String[0]);
//    cout << "The number of rows in String are " << StringRows << "\n\n";
//
//    for(int x=0; x < StringRows; x++)
//    {
//        if (ComparePhrase == String[x])
//            cout << ComparePhrase << " is equal to " << String[x] << ".\n";
//        else if (ComparePhrase < String[x])
//                cout << ComparePhrase << " is less than " << String[x] << ".\n";
//        else
//                cout << ComparePhrase << " is greater than " << String[x] << ".\n";
//    }
//
//    //***C-Strings
//    cout << "\n\n C-Stings\n\n";
//    char CompareCPhrase[] = "Hello World 2";
//    char CString[][15] {"Hello World 1", "Hello World 2", "Hello World 3"};
//    int CStringRows;
//
//    cout << "The number of bytes of CString are " << sizeof(CString) << "\n"; // returns total bytes in array
//        CStringRows = sizeof(CString)/sizeof(CString[0]);   // returns number of elements in array
//    cout << "The number of rows in CString are " << CStringRows << "\n\n";
//
//    for(int x=0; x < CStringRows; x++)
//    {
//        switch(strcmp(CompareCPhrase, CString[x]))  // compares strings
//        {
//            case 0: // returns 0 if comparison is equal
//                    cout << CompareCPhrase << " is equal to " << CString[x] << ".\n";
//                    break;
//            case -1:    // returns a negative number if less than
//                    cout << CompareCPhrase << " is less than " << CString[x] << ".\n";
//                    break;
//            case 1: // returns a positive number if greater than
//                    cout << CompareCPhrase << " is greater than " << CString[x] << ".\n";
//                    break;
//        }
//    }

//    cout << "\n";
//    SizeofStringArrays(String, CString);

    cout << "\n";
    return 0;
}

//void SizeofStringArrays(string String[], char CString[][15])
//{
//    cout << "The number of bytes of String are " << sizeof(String) << "\n";
//    cout << "The number of bytes of CString are " << sizeof(CString) << "\n\n"; // when passing an entire table, it's passed by reference, or by address,
//                                                                                // which is an integer. When passing only a portion, it's passed
//                                                                                // as is.
//
//    cout << "Length of Phrase: " << String[0].length() << "\n";
//    cout << "Length of CPhrase: " << strlen(CString[0]) << "\n\n";
//
//        cout << "Size of Phrase: " << sizeof(String[0]) << "\n";
//    cout << "Size of CPhrase: " << sizeof(CString[0]) << "\n\n";
//}
