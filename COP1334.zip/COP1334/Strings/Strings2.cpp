#include <iostream>
#include <string>
#include <cstring>

using namespace std;

int main()
{
    string String = "Hello world earth 123!";
    char CString[] = "Hello world earth 123!";

    //size_t fString = find_first_of(String);
    //size_t fCString = find_first_of(CString);

    cout << "In String, 'earth' is found in position: " << String.find("earth");
    cout << "\nIn CString, 'earth' is found in position: " << strstr(CString, "earth");

    return 0;
}
