#include <iostream>

using namespace std;

const char MATH_SYMBOL = '-';

int main()
{
    int a = 4, b = 22, c = 16;
    double x;

    // using increment operator to count
    b = b + 1;          // add 1 to b, and assign it back to b
    cout << b << endl;
    a = b++;             //assign b to a, then add 1 to b
    cout << b << endl;
    a = ++b;             //add 1 to b, and assign it to a
    cout << b << endl;

    // using increment operator alone
    ++b;
    cout << b << endl;
    b++;
    cjout << b << endl;

    return 0;
}
