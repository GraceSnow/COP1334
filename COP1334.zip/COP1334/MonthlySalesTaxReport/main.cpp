/*	Grace Benson		Student #R1234567
	Homework Assignment #1		Date 01/25/08

	This program will produce a report on daily profits from ticket sales.
	-------------------------------------------------------
	INPUT						    OUTPUT
	-----						    ------
	Month                           month, year, total collected sales
	Year                            county sales tax, state sales tax,
	Total collected sales           total sales tax
	-------------------------------------------------------
*/

//*** Program preprocessors - constants, libraries, and header files
#include <iostream>					//*** cin and cout
#include <iomanip>					//*** cout manipulator options
#include <string>					//*** string datatype
using namespace std;

int main()	//*****	 BEGINNING OF THE PROGRAM LOGIC	 *****
{
	const double STATE_SALES_TAX_RATE = .04, COUNTY_SALES_TAX_RATE = .02;
    double county_sales_tax, state_sales_tax, total_sales_tax, total_amount_collected, sales;
    string month, year;

	cout << "This program will produce a monthly sales tax report.\n\n";

	cout << "Enter Month: ";
	cin >> month;
	cout << "Enter Year: ";
	cin >> year;
	cout << "Enter total amount collected for the month: ";
	cin >> total_amount_collected;

	sales = total_amount_collected / 1.06;
	county_sales_tax = sales * COUNTY_SALES_TAX_RATE;
	state_sales_tax = sales * STATE_SALES_TAX_RATE;
	total_sales_tax = county_sales_tax + state_sales_tax;

    cout << fixed << setprecision(2);
	cout << "Month: " << month << " " << year << endl;
	cout << "-------------------\n";
	cout << left << setw(18) << "Total Collected: " << right << setw(10) << total_amount_collected << endl;
	cout << left << setw(18) << "Sales: " << right << setw(10) << sales << endl;
	cout << left << setw(18) << "County Sales Tax: " << right << setw(10) << county_sales_tax << endl;
	cout << left << setw(18) << "State Sales Tax: "  << right << setw(10) << state_sales_tax << endl;
	cout << "-------------------\n";
	cout << left << setw(18) << "Total Sales Tax: " << right << setw(10) << total_sales_tax << endl;



	return 0;
}	//***** 	END OF THE PROGRAM LOGIC	 *****
