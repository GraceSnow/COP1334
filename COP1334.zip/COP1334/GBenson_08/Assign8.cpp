/*	Grace Benson
	Assignment #8                      	04/05/17

	This program calculates the average of a group
	of test scores, dropping the lowest score.
	-------------------------------------------------------
	INPUT					    OUTPUT
	-----					    ------
	Test score 1, 2, 3, 4, 5    Average
	-------------------------------------------------------
*/

//*** Program preprocessors - constants, libraries, and header files
#include <iostream>				//*** cin and cout
#include <iomanip>				//*** cout manipulator options
#include <string>				//*** string datatype
#include <stdlib.h>             //*** clear screen
using namespace std;

// Prototypes
void DisplayDescription();
void getScore(int&);
int findLowest(int, int, int, int, int, int);
void calcAverage(int, int, int, int, int);

int main()	//*****	 BEGINNING OF THE PROGRAM LOGIC	 *****
{
	//*** Declaration and initialization of variables
	int Test1, Test2, Test3, Test4, Test5;

	system("cls");  //*** clear the screen

	//*** Program statements
    //*** Display description of the program
    DisplayDescription();

    //*** Request data
    getScore(Test1);
    getScore(Test2);
    getScore(Test3);
    getScore(Test4);
    getScore(Test5);

    //*** Process data and display results
    calcAverage(Test1, Test2, Test3, Test4, Test5);

	//*** Return to the operating system
	return 0;
}	//***** 	END OF THE PROGRAM LOGIC	 *****

void DisplayDescription()
{   /*
    Displays description of program
        Parameters - none
        Return - none
        Input - none
        Output - none
    */

    cout << "This program calculates the average of a group of test scores,";
    cout << "dropping the lowest score.\n";
	cout  << "\n\n";				//*** display 2 blank lines
}

void getScore(int &TestScore)
{   /*
    Asks user for test scores
        Parameters
            test score 1, 2, 3, 4, 5 - the 5 test scores must be between 0 and 100
    */

    cout << "Enter test score: ";
    cin >> TestScore;
    while(TestScore < 0 || TestScore > 100)
    {
        cout << "Error: The score must be between 0 and 100.\n";
        cout << "Enter test score: ";
        cin >> TestScore;
    }
}

int findLowest(int Test1, int Test2, int Test3, int Test4, int Test5)
{   /*
    Evaluate test scores for the lowest
        Parameters
            Test score 1, 2, 3, 4, 5 - test scores evaluated for lowest
        Returns
            Lowest - lowest test score
    */
    int Lowest = Test1;

    if(Test2 < Lowest)
            Lowest = Test2;
    if(Test3 < Lowest)
            Lowest = Test3;
    if(Test4 < Lowest)
            Lowest = Test4;
    if(Test5 < Lowest)
            Lowest = Test5;

    return Lowest;
}

void calcAverage(int Test1, int Test2, int Test3, int Test4, int Test5)
{   /*
    Calculates and displays the average of the four highest scores.
        Parameters
            Test score 1, 2, 3, 4, 5 - test scores
        Input
            lowest - the lowest score is dropped
        Output
            Average - average of the four highest scores
    */

    int Lowest = findLowest(Test1, Test2, Test3, Test4, Test5);
    double Average = static_cast<double>(Test1 + Test2 + Test3 + Test4 + Test5 - Lowest) / 4;

    cout << "The average of the test scores is " << Average << ".\n\n";
}
