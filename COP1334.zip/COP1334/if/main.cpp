#include <iostream>

using namespace std;

int main()
{
    //if statement
    /*for(int x=1, y=0; x<26; x++)
    {
        if(y++ == 5)
        {
            cout << "*****\n";
            y = 1;
        }
        cout << x << ". Hello world!" << endl;
    }*/

    // if/else statement
    for(int x=1, y=0, z = 0; x<26; x++)
    {
        if(y++ >= 5)
        {
            cout << "*****\n";
            y = 1;
        }
        else if(z++ >= 3)
        {
            cout << "$$$$$\n";
            z = 1;
        }
        else
        {
            cout << "_____\n";
        }

        cout << x << ". Hello world!" << endl;
    }
    return 0;
}
