/* Grace Benson
   Assignment #4

   This program will read the interest rate, starting balance, months, deposits,
   and withdrawals data from a file, then display it.
   --------------------------------------------------
   INPUT                        OUTPUT
   -----                        ------
   Interest rate                Interest rate
   Starting balance             Starting balance
   Months                       Months
   Deposits                     Deposits
   Withdrawals                  Withdrawals
                                Total withdrawn
                                Total deposited
                                Total interest earned
   --------------------------------------------------
*/

   //*** Program preprocessors - constants, libraries, and header files
#include <iostream>					//*** cin and cout
#include <iomanip>					//*** cout manipulator options
#include <string>					//*** string datatype
#include <stdlib.h>
#include <iostream>
#include <fstream> // Used to input to a file

using namespace std;

int main()
{
    string Balance, AnnualInterestRate, AmountDeposited, AmountWithdrawn;
    string TotalWithdrawn, TotalDeposited, TotalInterestEarned;                   // Variables read from file
    //double Balance = StartingBalance;                                                               // Assign starting balance to balance
    //double TotalWithdrawn = 0, TotalDeposited = 0, TotalInterestEarned = 0, MonthlyInterest=0;
    string Months;
    ifstream InputRecord;  // Variable name associated with input stream

    system("cls");  //** Clear screen
    //** Program description
    cout << "This program will read the interest rate, starting balance, months, deposits, \n";
    cout << "and withdrawals from a file, then display the data.\n\n";

    //** input stream associated with the output file
    InputRecord.open("Test.txt");

    if(!InputRecord)
    {
        //** show error message and end program if file is not found
        cout << "File not found!\n";
        return 0;   // Exit program
    }

    //InputRecord >> Balance >> TotalDeposited >> TotalInterestEarned >> AmountDeposited >> AmountWithdrawn;

    getline(InputRecord, Balance, ',');
    getline(InputRecord, TotalDeposited, ',');
    getline(InputRecord, TotalInterestEarned, ',');
    getline(InputRecord, AmountDeposited, ',');
    getline(InputRecord, AmountWithdrawn, ',');
    //** Print data
    cout << Balance << TotalDeposited << TotalInterestEarned << AmountDeposited << AmountWithdrawn;
    //while(!InputRecord.eof())
    //{


        //InputRecord >> AnnualInterestRate >> StartingBalance >> Months >> AmountDeposited >> AmountWithdrawn;
    //}
    /*for(int x = 1; x <= Months; x++)
    {
        InputRecord >> AmountDeposited >> AmountWithdrawn;
        cout << "\nEnter the amount deposited into the account during the month: ";
        cin >> AmountDeposited;
        while(AmountDeposited < 0)
        {
            cout << "\nThe amount deposited cannot be a negative amount.\n";
            cout << "Enter the amount deposited into the account during the month: ";
            cin >> AmountDeposited;
        }

        cout << "\nEnter the amount withdrawn from the account during the month: ";
        cin >> AmountWithdrawn;
        while(AmountWithdrawn < 0)
        {
            cout << "\nThe amount withdrawn cannot be a negative amount.\n";
            cout << "Enter the amount withdrawn from the account during the month: ";
            cin >> AmountWithdrawn;
        }



    }

    cout << "\n\nAccount Balance: " << setw(4) << setprecision(2) << fixed << right << Balance;
    cout << "\nTotal Deposits: " << setw(4) << setprecision(2) << fixed << right << TotalDeposited;
    cout << "\nTotal Withdrawn: " << setw(4) << setprecision(2) << fixed << right << TotalWithdrawn;
    cout << "\nTotal Interest Earned: " << setw(4) << setprecision(2) << fixed << right << TotalInterestEarned;
*/
    // Close input file
    InputRecord.close();

    return 0;
}

