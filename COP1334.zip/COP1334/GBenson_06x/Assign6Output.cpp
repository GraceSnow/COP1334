/* Grace Benson
   Assignment #4

   This program will ask the user to enter the interest rate, starting balance,
   months, deposits, and withdrawals, then write the data to a file.
   --------------------------------------------------
   INPUT                        OUTPUT
   -----                        ------
   Interest rate                Interest rate
   Starting balance             Starting balance
   Months                       Months
   Deposits                     Deposits
   Withdrawals                  Withdrawals
                                Total withdrawn
                                Total deposited
                                Total interest earned
   --------------------------------------------------
*/

// Preprocessors
#include <iostream> // cin and cout
#include <fstream>  // Used to output to a file
# include <iomanip> // cout manipulator options

using namespace std;

int main()
{
    double Balance, AnnualInterestRate, AmountDeposited, AmountWithdrawn;
    double TotalWithdrawn = 0, TotalDeposited = 0, TotalInterestEarned = 0, MonthlyInterest=0;
    int Months;
    ofstream OutputRecord;  // Variable name associated with output stream

    // Output stream associated with the input file
    OutputRecord.open("Test.txt");

    if(!OutputRecord)
    {
        //** show error message and end program if file is not found
        cout << "File not found!\n";
        return 0;   // Exit program
    }

    // Program description
    cout << "This program will ask the user to enter the interest rate,\n";
    cout << "starting balance, months, deposits, and withdrawals, then write the\n";
    cout << "data to a file.\n\n";

    //** Get annual interest rate
    cout << "Enter the annual interest rate of the account: ";
    cin >> AnnualInterestRate;
    while(AnnualInterestRate <= 0)
    {
        // Validate annual interest rate is greater than 0.
        cout << "The annual interest rate must be greater than 0.\nEnter another number: ";
        cin >> AnnualInterestRate;
    }

    //** Get balance
    cout << "\nEnter the starting balance of the account: ";
    cin >> Balance;
    while(Balance <= 1000)
    {
        // Validate starting balance is greater than 1000.
        cout << "The starting balance must be greater than 1000.\nEnter another number: ";
        cin >> Balance;
    }

    //** Get number of months
    cout << "\nEnter the number of months that have passed since the account\n";
    cout << "was established: ";
    cin >> Months;
    while(Months <= 1)
    {
        // Validate Months is greater than 1.
        cout << "The number of months must be greater than 1.\n Enter another number. ";
        cin >> Months;
    }
    cout << endl << endl;

    for(int x = 1; x <= Months; x++)
    {
        // Loop for number of months

        cout << endl << x << ". Enter the amount deposited into the account during the month: ";
        cin >> AmountDeposited;
        while(AmountDeposited <= 0)
        {
            // Validate deposits are greater than 0.
            cout << "\nThe amount deposited cannot be a negative amount.\n";
            cout << "Enter the amount deposited into the account during the month: ";
            cin >> AmountDeposited;
        }

        cout << endl << x << ". Enter the amount withdrawn from the account during the month: ";
        cin >> AmountWithdrawn;
        while(AmountWithdrawn <= 0)
        {
            // Validate withdrawals are greater than 0.
            cout << "\nThe amount withdrawn cannot be a negative amount.\n";
            cout << "Enter the amount withdrawn from the account during the month: ";
            cin >> AmountWithdrawn;
        }

        Balance += AmountDeposited - AmountWithdrawn;
        MonthlyInterest = (AnnualInterestRate / 12) * Balance;
        Balance += MonthlyInterest;

        if(Balance < 0)
            {
                cout << "\n\nThe account balance is negative.\n\n";
                break;
            }

        TotalWithdrawn += AmountWithdrawn;
        TotalDeposited += AmountDeposited;
        TotalInterestEarned += MonthlyInterest;
    }

    //** Write data to file
    OutputRecord << "Account Balance: $" << setw(4) << setprecision(2) << fixed << right << Balance << endl;
    OutputRecord << "Total Deposits: $" << setw(4) << setprecision(2) << fixed << right << TotalDeposited << endl;
    OutputRecord << "Total Withdrawn: $" << setw(4) << setprecision(2) << fixed << right << TotalWithdrawn << endl;
    OutputRecord << "Total Interest Earned: $" << setw(4) << setprecision(2) << fixed << right << TotalInterestEarned << endl;

    // Close output file
    OutputRecord.close();

    return 0;
}
